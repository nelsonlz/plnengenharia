<?php
/*
 * Este arquivo é parte do Software CRM - Vendas Online
 * Copyright (c) 2013 Sistemas Cordon (http://www.scordon.com.br/)
 * 
 * Para maiores informações sobre a licença leia o arquivo license.txt
 */
require_once 'model/IO/FileIO.class.php';
//echo 'teste';
/**
 * * Classe responsavel tratar de operações de leitura e escrita de arquivos e dados
 * em disco, e criptografia
 * @package IO
 * @copyright (c) 2013, Sistemas Cordon <http://www.scordon.com.br/>
 * @author  Fernando Eugenio Augusto de Carvalho. <fernando@scordon.com.br>
 * @version 1.0
 */

class TrataArquivoConfiguracao extends FileIO
{
    protected $aFilename = "model/config/config.txt";
    protected $cDelimitador = "|";
    public function __construct() 
    {

           parent::__construct($this->aFilename, $this->cDelimitador); 
        
    }
    public function xaGetLayoutBase64(){
        $tmp = explode("|", parent::xaGetLine(0));
        $layout = base64_decode($tmp[0]);
        return $layout;
    }
    public function xvAlteraCampoBase64($nPos, $aValor){
        $tmp = explode("|", parent::xaGetLine(0));
        if($nPos >= count($tmp)){
            return false;
        }else{
            $tmp = base64_decode($tmp);
            $tmp[$nPos] = $aValor;
            for ($i=0; $i < count($tmp); $i++){
                if ($i == 0){
                    parent::xvWriteBase64($tmp[$i], "w+");
                }else{
                    parent::xvWriteBase64($tmp[$i], "a+"); 
                }
            }
        }
    }
}
?>