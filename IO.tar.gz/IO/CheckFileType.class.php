<?php
/*
 * Este arquivo é parte do Software CRM - Vendas Online
 * Copyright (c) 2013 Sistemas Cordon (http://www.scordon.com.br/)
 * 
 * Para maiores informações sobre a licença leia o arquivo license.txt
 */

/**
 * * Classe responsavel por testar a validade de arquivos de entrada.
 * @package IO
 * @copyright (c) 2013, Sistemas Cordon <http://www.scordon.com.br/>
 * @author  Nelson Luiz Prado Canabarro de Oliveira. <nelson@scordon.com.br>
 * @version 1.0
 */
class CheckFileType {
    private static $aImag = array('jpg', 'jpeg','png', 'gif', 'tiff', 'bmp');
    private static $aDoc  = array('doc','docx','odt','pdf','txt');
    
    private static function xfIsValidType($aFileName,$aList)
    {
        $tmp = explode('.',$aFileName);
        return in_array($tmp[count($tmp)], $aList);
    }
    public function xfIsImage($aFileName)
    {
        return self::isValidType($aFileName, self::$imagem);
    }
    public function xfIsDoc($aFileName)
    {
        return self::isValidType($aFileName, self::$imagem);
    }
}

?>
