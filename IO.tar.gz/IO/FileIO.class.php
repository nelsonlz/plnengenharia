<?php
/*
 * Este arquivo é parte do Software CRM - Vendas Online
 * Copyright (c) 2013 Sistemas Cordon (http://www.scordon.com.br/)
 * 
 * Para maiores informações sobre a licença leia o arquivo license.txt
 */

/**
 * * Classe responsavel tratar de operações de leitura e escrita de arquivos e dados
 * em disco, e criptografia
 * @package IO
 * @copyright (c) 2013, Sistemas Cordon <http://www.scordon.com.br/>
 * @author  Nelson Luiz Prado Canabarro de Oliveira. <nelson@scordon.com.br>
 * @version 1.0
 */
class FileIO 
{
    private $aFileName;
    private $File = null;
    private $nSize = 0;
    private $aHash = array();
    private $cDelimitador = '';
    private $nLines = 0;
    
    
    public function __construct($aFile, $cDelimitador)
    {
        $this->cDelimitador = $cDelimitador;
        $this->aFileName = $aFile;
        if(!file_exists($aFile))
        {
            $this->File = fopen($this->aFileName,'w+');
        }
        else
        {
            $this->File = fopen($this->aFileName,"r");
            $this->nSize = filesize($this->aFileName);
        }
        fclose($this->File);
        $this->xvCriaHash();
        $this->nLines = count($this->aHash)-1;
    }
    
    private function xvCriaHash()
    {
        $this->File = fopen($this->aFileName,"r");
        $nCont = 0;
        $this->aHash = array();
        $this->aHash[0] = 0;
        while(!feof($this->File))
        {
            $tmp = fgetc($this->File);
            $nCont++;
            if($tmp == $this->cDelimitador)
            {
                $this->aHash[] = $nCont;
            }
        }
        fclose($this->File);
    }
    
    public function xnGetSize()
    {
        return $this->nSize;
    }
    
    public function xnGetNlines()
    {
        return $this->nLines;
    }

    public function xvWrite($aTxt,$cfModo)
    {
        $tmp = $this->xaRemoveEspacoFinal($aTxt);
        $this->File = fopen($this->aFileName, $cfModo);
        fwrite($this->File, $tmp.$this->cDelimitador);
        fclose($this->File);
        $this->xvCriaHash();
        $this->nLines = count($this->aHash)-1;
    }
    
    public function xvWriteBase64($aTxt,$cfModo)
    {
        $tmp = base64_encode($aTxt);
        $this->File = fopen($this->aFileName, $cfModo);
        fwrite($this->File, $tmp.$this->cDelimitador);
        fclose($this->File);
        $this->xvCriaHash();
        $this->nLines = count($this->aHash)-1;
    }

    public function xaGetLine($nLin)
    {
        if($nLin > $this->nLines)
            return "";
        if($nLin == $this->nLines)
            $nLin = $nLin - 1;
        $this->File = fopen($this->aFileName, "r");
        fseek($this->File, $this->aHash[$nLin]);
        $tmp =  fgets($this->File);
        fclose($this->File);
        return $tmp;
    }
    
    private function xaRemoveEspacoFinal($aTxt)
    {
        if($aTxt{strlen($aTxt)-1} == ' ')
            $aTxt{strlen($aTxt)-1} = '';
         return $aTxt;
    }
    
    public function xaGetLineArray($nLin,$cDelimitador)
    {
        if($nLin > $this->nLines)
            return "";
        if($nLin == $this->nLines)
            $nLin = $nLin - 1;
        $this->File = fopen($this->aFileName, "r");
        fseek($this->File, $this->aHash[$nLin]);
        $tmp =  fgets($this->File);
        fclose($this->File);
        $aTmp = explode($cDelimitador, $tmp);
        $aSaida = array();
        $aSaida[0] = $this->xaRemoveEspacoFinal($aTmp[0]);
        $aSaida[1] = $this->xaRemoveEspacoFinal($aTmp[1]);

        return $aSaida;
    }
    
    public function xaGetLineArrayDecodB64($nLin,$cDelimitador)
    {
        if($nLin > $this->nLines)
            return "";
        if($nLin == $this->nLines)
            $nLin = $nLin - 1;
        $this->File = fopen($this->aFileName, "r");
        fseek($this->File, $this->aHash[$nLin]);
        $tmp =  fgets($this->File);
        fclose($this->File);
        $tmp = base64_decode($tmp);
        $aTmp = explode($cDelimitador, $tmp);
        $aSaida = array();
        $aSaida[0] = $this->xaRemoveEspacoFinal($aTmp[0]);
        $aSaida[1] = $this->xaRemoveEspacoFinal($aTmp[1]);

        return $aSaida;
    }
        public function xaGetAllArrayDecodB64($cDelimitador)
    {
        $tmp = file_get_contents($this->aFileName);
        $aTmp = explode($cDelimitador, $tmp);
        $aSaida = array();
        
        for($nI = 0; $nI < count($aTmp) -1; $nI++)
        {
//            $tmp[$nI] = base64_decode($tmp[$nI]);
            array_push($aSaida, base64_decode($aTmp[$nI]));
        }
        return $aSaida;
    }
        public function xvNewFIle($aExpRegIni, $aExpRegFim, $aExt)
    {
        $aTmpNome = explode('.', $this->aFileName);
        $aNovoNome = $aTmpNome[0]. "." . $aExt;
        $aNovoFile = fopen($aNovoNome, "w+");

        for($ni=0;$ni<$this->nLines; $ni++){
           
            if (preg_match($aExpRegIni,  $this->xaGetLine($ni))){

                for ($ny=$ni;$ny<$this->nLines; $ny++){

                    if (!preg_match($aExpRegFim, $this->xaGetLine($ny))){
                        fwrite($aNovoFile, $this->xaGetLine($ny));
                    }else {
                        $ni = $ny;
                        fwrite($aNovoFile, $this->xaGetLine($ni));
                        break;
                    }
                }
            }
            if($ni == $this->nLines){
            fclose($this->File);
            }
        }
    }
    
     
}

?>
